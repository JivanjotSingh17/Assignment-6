"use strict";

const createStopwatch = (minuteSpan, secondSpan, msSpan) => {
    // private state
    let stopwatchTimer;
    let elapsed = { minutes: 0, seconds: 0, milliseconds: 0 };

    // private function to pad single digit
    const padSingleDigit = num => num.toString().padStart(2, "0");

    // private function to update stopwatch time
    const tickStopwatch = () => {
        elapsed.milliseconds += 10;

        if (elapsed.milliseconds === 1000) {
            elapsed.seconds++;
            elapsed.milliseconds = 0;
        }

        if (elapsed.seconds === 60) {
            elapsed.minutes++;
            elapsed.seconds = 0;
        }

        minuteSpan.text(padSingleDigit(elapsed.minutes));
        secondSpan.text(padSingleDigit(elapsed.seconds));
        msSpan.text(elapsed.milliseconds);
    };

    // public methods
    const start = () => {
        tickStopwatch();
        stopwatchTimer = setInterval(tickStopwatch, 10);
    };

    const stop = () => {
        clearInterval(stopwatchTimer);
    };

    const reset = () => {
        clearInterval(stopwatchTimer);
        elapsed = { minutes: 0, seconds: 0, milliseconds: 0 };
        minuteSpan.text("00");
        secondSpan.text("00");
        msSpan.text("000");
    };

    // Return public methods
    return {
        start: start,
        stop: stop,
        reset: reset
    };
};

// Example usage:
const stopwatch = createStopwatch($("#s_minutes"), $("#s_seconds"), $("#s_ms"));

$("#start").click(() => {
    stopwatch.start();
});

$("#stop").click(() => {
    stopwatch.stop();
});

$("#reset").click(() => {
    stopwatch.reset();
});
