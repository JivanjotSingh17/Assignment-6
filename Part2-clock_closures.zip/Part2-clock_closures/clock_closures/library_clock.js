"use strict";

const createClock = (hourSpan, minuteSpan, secondSpan, ampmSpan) => {
    // private state
    let clockTimer;

    // private function to pad single digit
    const padSingleDigit = num => num.toString().padStart(2, "0");

    // private function to display current time
    const displayCurrentTime = () => {
        const now = new Date();
        let hours = now.getHours();
        let ampm = "AM";

        if (hours > 12) {
            hours = hours - 12;
            ampm = "PM";
        } else {
            switch (hours) {
                case 12:
                    ampm = "PM";
                    break;
                case 0:
                    hours = 12;
                    ampm = "AM";
            }
        }

        hourSpan.text(padSingleDigit(hours));
        minuteSpan.text(padSingleDigit(now.getMinutes()));
        secondSpan.text(padSingleDigit(now.getSeconds()));
        ampmSpan.text(ampm);
    };

    // public methods
    const start = () => {
        displayCurrentTime();
        clockTimer = setInterval(displayCurrentTime, 1000);
    };

    const stop = () => {
        clearInterval(clockTimer);
    };

    // Return public methods
    return {
        start: start,
        stop: stop
    };
};

// Example usage:
const clock = createClock($("#hours"), $("#minutes"), $("#seconds"), $("#ampm"));

$("#start").click(() => {
    clock.start();
});

$("#stop").click(() => {
    clock.stop();
});
