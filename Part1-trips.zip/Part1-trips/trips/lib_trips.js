// Updated library_trips.js

var tripsModule = (function () {
  // Private state
  const _trips = [];

  // Private method to calculate total kilometers
  function calculateTotalKml() {
      let totalKm = 0;
      let totalLitres = 0;
      for (let trip of _trips) {
          totalKm += trip.km;
          totalLitres += trip.litres;
      }
      return totalKm / totalLitres;
  }

  // Public methods and properties
  return {
      // Public method to push a Trip object to the array
      push: function (trip) {
          // only allow Trip objects to be added to array
          if (trip instanceof Trip) {
              _trips.push(trip);
          }
      },

      // Public method to get the total kilometers
      totalKml: function () {
          return calculateTotalKml();
      },

      // Public method to convert the trips to a string
      toString: function () {
          let str = "";
          for (let trip of _trips) {
              str += trip.toString() + "\n";
          }
          str += "\nCumulative KML: " + calculateTotalKml().toFixed(1);
          return str;
      },
  };
})();
